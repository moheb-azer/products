<?php
return [
    "database" => [
        "host" => "127.0.0.1",
        "port" => 3306,
        "dbname" => "xhfgazmy_scandiweb",
        "charset" => "utf8mb4",
    ],
];