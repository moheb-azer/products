<?php require('layout/header.php'); ?>
<div class="fs-1 ml-auto mt-auto">404 Page Not Found... <a href="/" class="btn btn-secondary">go to home page</a></div>
<?php include('layout/footer.php'); ?>
